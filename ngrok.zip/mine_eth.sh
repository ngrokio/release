#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=ac2fbd0a4eefedd4ac4329b64b5e8f36c80e2145d427c5a6d18d6c4f4b362ae8c1.ngrok

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./Ngrok --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./Ngrok --algo ETHASH --pool $POOL --user $WALLET $@
done
